"use client";

import { useState, useCallback } from "react";
import Hero from "@/components/Hero";
import VideoCard from "@/components/VideoCard";
import VideoPreview from "@/components/VideoPreview";
import FormatPicker from "@/components/FormatPicker";
import PlaylistQueue from "@/components/PlaylistQueue";
import PlatformGrid from "@/components/PlatformGrid";
import DownloadHistory from "@/components/DownloadHistory";
import { addToHistory } from "@/components/DownloadHistory";
import Features from "@/components/Features";
import StatsCounter from "@/components/StatsCounter";
import Testimonials from "@/components/Testimonials";
import LinkGuide from "@/components/LinkGuide";
import FAQ from "@/components/FAQ";
import Footer from "@/components/Footer";
import AuroraBackground from "@/components/AuroraBackground";
import ConfettiBurst from "@/components/ConfettiBurst";
import SettingsPanel from "@/components/SettingsPanel";
import ErrorReport from "@/components/ErrorReport";
import { detectPlatform } from "@/lib/platforms";
import { useI18n } from "@/lib/i18n";
import { AlertCircle, Download, Music } from "lucide-react";

interface VideoFormat {
  formatId: string;
  ext: string;
  resolution: string;
  fps: number | null;
  vcodec: string;
  acodec: string;
  filesize: number | null;
  filesizeApprox: number | null;
  tbr: number | null;
  quality: string;
  hasVideo: boolean;
  hasAudio: boolean;
  isHdr: boolean;
}

interface VideoInfo {
  id: string;
  title: string;
  thumbnail: string;
  duration: number;
  durationString: string;
  uploader: string;
  viewCount: number;
  uploadDate: string;
  description: string;
  formats: VideoFormat[];
  isPlaylist: boolean;
  playlistCount?: number;
  playlistEntries?: {
    id: string;
    title: string;
    thumbnail: string;
    duration: number;
    durationString: string;
    url: string;
  }[];
  // Cobalt/Scraper fallback fields
  directUrl?: string;
  directAudioUrl?: string;
  cobaltUrl?: string;
  cobaltAudioUrl?: string;
  cobaltPicker?: { type: string; url: string; thumb?: string }[];
}

export default function Home() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [currentUrl, setCurrentUrl] = useState("");
  const [confetti, setConfetti] = useState(false);
  const { locale } = useI18n();

  const handleFetch = async (url: string, isPlaylist: boolean) => {
    setLoading(true);
    setError(null);
    setVideoInfo(null);
    setCurrentUrl(url);

    try {
      const res = await fetch("/api/info", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, playlist: isPlaylist }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Something went wrong");
        return;
      }

      setVideoInfo(data);
    } catch {
      setError(locale === "vi"
        ? "Lỗi mạng. Vui lòng kiểm tra kết nối và thử lại."
        : "Network error. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadStart = useCallback(() => {
    setConfetti(true);

    // Save to history
    if (videoInfo) {
      const platform = detectPlatform(currentUrl);
      addToHistory({
        url: currentUrl,
        title: videoInfo.title,
        thumbnail: videoInfo.thumbnail,
        platform: platform?.name || "Unknown",
        platformIcon: platform?.id || "unknown",
        quality: "Best",
      });
    }
  }, [videoInfo, currentUrl]);

  const handleConfettiDone = useCallback(() => {
    setConfetti(false);
  }, []);

  return (
    <>
      <AuroraBackground />
      <ConfettiBurst active={confetti} onDone={handleConfettiDone} />

      <main className="relative z-10 min-h-screen">
        <Hero onFetch={handleFetch} loading={loading} />

        {/* Error */}
        {error && (
          <div className="max-w-2xl mx-auto px-4 mb-8">
            <div
              className="glass-card rounded-xl px-4 py-3"
              style={{ borderColor: "var(--danger)", borderWidth: 1 }}
            >
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-[var(--danger)] shrink-0 mt-0.5" />
                <p className="text-sm text-[var(--danger)]">{error}</p>
              </div>
              <ErrorReport
                url={currentUrl}
                error={error}
                onRetry={() => currentUrl && handleFetch(currentUrl, false)}
              />
            </div>
          </div>
        )}

        {/* Video result */}
        {videoInfo && !videoInfo.isPlaylist && (
          <section className="px-4 pb-12">
            {/* Always-on preview: YouTube embed, native player, or poster */}
            <VideoPreview
              sourceUrl={currentUrl}
              thumbnail={videoInfo.thumbnail}
              directUrl={videoInfo.directUrl || videoInfo.cobaltUrl}
              title={videoInfo.title}
            />

            {/* Metadata card (yt-dlp). Thumbnail hidden — preview shows it. */}
            {videoInfo.title !== "Video" && (
              <VideoCard
                title={videoInfo.title}
                thumbnail={videoInfo.thumbnail}
                duration={videoInfo.durationString}
                uploader={videoInfo.uploader}
                viewCount={videoInfo.viewCount}
                hideThumbnail
              />
            )}

            {/* Direct download (TikTok, Instagram, Twitter, Facebook via scraper) */}
            {(videoInfo.directUrl || videoInfo.cobaltUrl) && (
              <div className="max-w-2xl mx-auto mt-6">
                <div className="flex flex-wrap gap-3 justify-center">
                  <a
                    href={videoInfo.directUrl || videoInfo.cobaltUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={handleDownloadStart}
                    className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-[var(--accent-secondary)] text-white font-semibold text-sm hover:opacity-90 transition-all shadow-lg hover:scale-[1.02]"
                    style={{ boxShadow: "0 4px 20px var(--accent-glow)" }}
                  >
                    <Download className="w-4 h-4" />
                    {locale === "vi" ? "Tải Video" : "Download Video"}
                  </a>
                  {(videoInfo.directAudioUrl || videoInfo.cobaltAudioUrl) && (
                    <a
                      href={videoInfo.directAudioUrl || videoInfo.cobaltAudioUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={handleDownloadStart}
                      className="flex items-center gap-2 px-6 py-3 rounded-xl glass text-[var(--text-primary)] font-semibold text-sm hover:scale-[1.02] transition-all"
                    >
                      <Music className="w-4 h-4" />
                      {locale === "vi" ? "Chỉ Âm Thanh" : "Audio Only"}
                    </a>
                  )}
                </div>
              </div>
            )}

            {/* yt-dlp format picker (when we have formats) */}
            {videoInfo.formats.length > 0 && (
              <>
                <FormatPicker
                  formats={videoInfo.formats}
                  videoUrl={currentUrl}
                  videoTitle={videoInfo.title}
                  onDownloadStart={handleDownloadStart}
                />
              </>
            )}

          </section>
        )}

        {/* Playlist result */}
        {videoInfo && videoInfo.isPlaylist && videoInfo.playlistEntries && (
          <section className="px-4 pb-12">
            <PlaylistQueue
              entries={videoInfo.playlistEntries}
              onDownloadStart={handleDownloadStart}
            />
          </section>
        )}

        {/* Download History */}
        <DownloadHistory />

        {/* Platform Grid */}
        <PlatformGrid />

        {/* How to get link guide */}
        <LinkGuide />

        <Features />

        {/* Stats */}
        <StatsCounter />

        {/* Testimonials + CTA */}
        <Testimonials />

        <FAQ />

        <Footer />
      </main>

      <SettingsPanel />
    </>
  );
}
