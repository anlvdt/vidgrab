globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/6Cz8EOY5sCK1BH2o8LL2O/_buildManifest.js",
    "static/6Cz8EOY5sCK1BH2o8LL2O/_ssgManifest.js",
    "static/6Cz8EOY5sCK1BH2o8LL2O/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1ee4c-6fpawm5.js",
    "static/chunks/15orcrkp-_9ct.js",
    "static/chunks/2ncdmtj91g36a.js",
    "static/chunks/2qr_3xmpwcjvb.js",
    "static/chunks/turbopack-1nw59kke0fumg.js"
  ]
};
