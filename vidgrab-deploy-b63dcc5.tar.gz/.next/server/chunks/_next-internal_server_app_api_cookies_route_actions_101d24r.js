module.exports=[87142,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cookies_route_actions_101d24r.js.map