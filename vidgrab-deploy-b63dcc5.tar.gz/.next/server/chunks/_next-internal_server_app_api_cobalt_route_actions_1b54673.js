module.exports=[30485,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cobalt_route_actions_1b54673.js.map