module.exports=[12060,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_info_route_actions_1fdi2bl.js.map