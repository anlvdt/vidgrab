var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cobalt/route.js")
R.c("server/chunks/[root-of-the-server]__1oakpfr._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/_next-internal_server_app_api_cobalt_route_actions_1b54673.js")
R.m(62996)
module.exports=R.m(62996).exports
