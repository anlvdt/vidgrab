var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cookies/route.js")
R.c("server/chunks/[root-of-the-server]__18ul6k4._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/_next-internal_server_app_api_cookies_route_actions_101d24r.js")
R.m(82435)
module.exports=R.m(82435).exports
