var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/download/route.js")
R.c("server/chunks/[root-of-the-server]__1ngb-t7._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/src_lib_ytdlp_ts_02zf5on._.js")
R.c("server/chunks/_next-internal_server_app_api_download_route_actions_07yss3k.js")
R.m(28101)
module.exports=R.m(28101).exports
