var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/report/route.js")
R.c("server/chunks/[root-of-the-server]__1dwp5cp._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/_next-internal_server_app_api_report_route_actions_0i4hyhm.js")
R.m(69099)
module.exports=R.m(69099).exports
