var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/info/route.js")
R.c("server/chunks/[root-of-the-server]__09lziwz._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0kpba69.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/src_lib_ytdlp_ts_02zf5on._.js")
R.c("server/chunks/_next-internal_server_app_api_info_route_actions_1fdi2bl.js")
R.m(15182)
module.exports=R.m(15182).exports
